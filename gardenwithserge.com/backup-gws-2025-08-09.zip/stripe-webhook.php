<?php
// === Stripe Webhook Endpoint ===
// Works with Composer-installed packages in /garden/vendor
// Expects STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET in garden/.env

// 1) Load Composer packages (Stripe SDK + phpdotenv)
require __DIR__ . '/../garden/vendor/autoload.php';

// 2) (Optional) Load your DB connection if you need it later
//    Keep this if you already had it in your original file.
require_once 'db_config.php';

// 3) Load environment variables from /garden/.env
//    Make sure garden/.env exists on the server and contains:
//      STRIPE_SECRET_KEY=sk_live_...
//      STRIPE_WEBHOOK_SECRET=whsec_...
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../garden');
$dotenv->safeLoad();

// 4) Configure Stripe using the secret key from .env
\Stripe\Stripe::setApiKey(getenv('STRIPE_SECRET_KEY'));

// 5) Read and verify the incoming webhook using the signing secret from .env
$endpoint_secret = getenv('STRIPE_WEBHOOK_SECRET');
$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? null;

try {
    if (!$sig_header) {
        // Missing Stripe signature header
        http_response_code(400);
        exit();
    }
    // Verify signature and parse the event
    $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $endpoint_secret);

} catch (\UnexpectedValueException $e) {
    // Invalid payload
    http_response_code(400);
    exit();

} catch (\Stripe\Exception\SignatureVerificationException $e) {
    // Invalid signature
    http_response_code(400);
    exit();
}

// 6) Handle events
switch ($event->type) {
    case 'checkout.session.completed':
        // The Checkout Session object
        $session = $event->data->object;

        // Useful fields
        $checkout_session_id = $session->id ?? null;
        $payment_status      = $session->payment_status ?? null; // usually "paid"
        $amount_total        = isset($session->amount_total) ? ($session->amount_total / 100.0) : null; // cents -> dollars
        $currency            = $session->currency ?? null;
        $customer_email      = $session->customer_details->email ?? null;

        // If you set metadata when creating the Checkout Session (e.g., order_id)
        $order_id = $session->metadata->order_id ?? null;

        // Log to confirm it works (adjust path if needed).
        // Ensure the web server can write to garden/stripe_webhook.log
        @file_put_contents(
            __DIR__ . '/../garden/stripe_webhook.log',
            date('c') . " checkout.session.completed: session={$checkout_session_id}, email={$customer_email}, status={$payment_status}, order_id={$order_id}, amount={$amount_total} {$currency}\n",
            FILE_APPEND
        );

        // ---- Example DB update (leave commented until you're ready) ----
        // NOTE: Adapt to your actual schema and db_config.php variables.

        // // If you have mysqli in db_config.php as $conn:
        // if (isset($conn) && $conn instanceof mysqli && $order_id) {
        //     $stmt = $conn->prepare("UPDATE orders SET status='paid', paid_at=NOW(), amount=?, currency=? WHERE order_id=?");
        //     $stmt->bind_param("dss", $amount_total, $currency, $order_id);
        //     $stmt->execute();
        //     $stmt->close();
        // }

        // // If you have PDO in db_config.php as $pdo:
        // if (isset($pdo) && $pdo instanceof PDO && $order_id) {
        //     $stmt = $pdo->prepare("UPDATE orders SET status='paid', paid_at=NOW(), amount=:amount, currency=:currency WHERE order_id=:order_id");
        //     $stmt->execute([
        //         ':amount'   => $amount_total,
        //         ':currency' => $currency,
        //         ':order_id' => $order_id,
        //     ]);
        // }

        break;

    default:
        // Uncomment to log other events:
        // @file_put_contents(__DIR__ . '/../garden/stripe_webhook.log', date('c') . " Ignored event: {$event->type}\n", FILE_APPEND);
        break;
}

// 7) Acknowledge receipt so Stripe doesn't retry
http_response_code(200);
